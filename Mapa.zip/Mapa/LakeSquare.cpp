#include "LakeSquare.h"
LakeSquare::LakeSquare()
{
    this->square_type = 'L';

}
char LakeSquare::getTypeSquare()
{
	return this->square_type;
}

LakeSquare:: ~LakeSquare(){
}