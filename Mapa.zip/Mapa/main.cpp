#include <iostream>
#include "Map.h"

using namespace std;

int main()
{
    Map map;
    map.showMap();
    return 0;
}
