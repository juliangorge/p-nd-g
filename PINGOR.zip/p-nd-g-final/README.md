# p-nd-g
P&amp;G

-Se le asigna un caracter al objeto edificio  o material en base al primer caracter de su nombre, por lo tanto, si se tiene por ejemplo los edificios Mina y Monasterios, ambos se veran representados en el mapa con una M

-En el ingreso del nombre del edificio por consola del edificio a construir, se utilizo el comando getlina(cin, name) 2 VECES ya que por alguna razon, al colocar una vez el comando, name tenia asignado el \n de la opcion anterior.
